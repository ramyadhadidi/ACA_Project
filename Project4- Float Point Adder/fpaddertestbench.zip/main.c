#include <time.h>
#include <stdio.h>
#include <stdlib.h>

float f_rand(){

    int x;
    float f;

    x = (rand() << 16) + rand();

    if ( (x & 0x7f800000) == 0x7f800000 )    // filter out of E = 0xFF, i.e. non-regular numbers
        return(f_rand());

    *((int *) &f) = x;

    return(f);
}



int main(){

    int i;

    float a, b, c, d;

/*
    // set a float number with an specific binary pattern
    *((int *) &a) = 0x407fffff;
    *((int *) &b) = 0x33800000;

    // do float add or sub on them
    c = a + b;
    d = a - b;

    // print binary pattern of a float
    printf("%x %x %x %x\n", *((int *) &a), *((int *) &b), *((int *) &c), *((int *) &d));
*/

    srand(time(0));

    for(i=0; i<10000; i++) {

        a = f_rand();

        if( i < 100 )
            b = a;
        else if( i < 200 )
            b = a / (1 << 24);
        else if( i < 300 )
            b = a + a / (1 << 24);
//        else if( i < 400 ) {
//            b = a;
//            a = 0;
//        }
        else
            b = f_rand();

        c = a + b;
        d = a - b;

        if( c == a || c == b || d == a || d == b){
            i--;
            continue;
        }

        if( *((int *) &c) == 0x7f800000 || *((int *) &d) == 0x7f800000 ){
            i--;
            continue;
        }

        printf("%x %x %x %x\n", *((int *) &a), *((int *) &b), *((int *) &c), *((int *) &d));

    }

    return(0);
}

